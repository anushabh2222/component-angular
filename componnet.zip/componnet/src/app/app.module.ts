import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {MatListModule} from '@angular/material/list';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {MatRadioModule} from '@angular/material/radio';
import {MatMenuModule} from '@angular/material/menu';
import {MatPaginatorModule} from '@angular/material/paginator';
import {MatIconModule} from '@angular/material/icon';
import {MatProgressBarModule} from '@angular/material/progress-bar'
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner'
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RadioComponent } from './radio/radio.component';
import { ListComponent } from './list/list.component';
import { MenuComponent } from './menu/menu.component';
import { PaginatorComponent } from './paginator/paginator.component';
import { IconComponent } from './icon/icon.component';
import { ProgressbarComponent } from './progressbar/progressbar.component';
import { ProgressspinnerComponent } from './progressspinner/progressspinner.component';



@NgModule({
  declarations: [
    AppComponent,
    RadioComponent,
    ListComponent,
    MenuComponent,
    PaginatorComponent,
    IconComponent,
    ProgressbarComponent,
    ProgressspinnerComponent,
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatRadioModule,
    MatListModule,
    MatMenuModule,
    MatPaginatorModule,
    MatIconModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
   
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
