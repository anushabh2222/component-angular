import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-progressspinner',
  templateUrl: './progressspinner.component.html',
  styleUrls: ['./progressspinner.component.css']
})
export class ProgressspinnerComponent implements OnInit {

  constructor() { }

  validate:boolean=false;
  ngOnInit(): void {
  }
  goToProgressspinner()
  {
this.validate=true;
  }

}
